#include <iostream>
#include <unistd.h>
using namespace std;

int main ()
{
	cout<<"I am process : "<<getpid()<<endl;
	return 0;
}
